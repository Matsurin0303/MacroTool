﻿namespace MacroTool.Domain
{
    public class Class1
    {

    }
}
