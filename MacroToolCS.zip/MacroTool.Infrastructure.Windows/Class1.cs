﻿namespace MacroTool.Infrastructure.Windows
{
    public class Class1
    {

    }
}
