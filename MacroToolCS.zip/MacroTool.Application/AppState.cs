﻿namespace MacroTool.Application;

public enum AppState
{
    Stopped,
    Recording,
    Playing
}
