﻿namespace MacroTool.Application
{
    public class Class1
    {

    }
}
