using System.IO;
using MacroTool.WinForms.Core; // �ǉ��i�u�����ꏊ�ɍ��킹��j
using MacroTool.Application.Services;
using MacroTool.Domain.Macros;
using MacroTool.WinForms.Core;
using System;
using System.Drawing;
using System.ComponentModel;
using DomainMacroAction = MacroTool.Domain.Macros.MacroAction;
using DomainMouseClick = MacroTool.Domain.Macros.MouseClick;
using DomainKeyDown = MacroTool.Domain.Macros.KeyDown;
using DomainKeyUp = MacroTool.Domain.Macros.KeyUp;

namespace MacroToolCS;

public partial class Form1 : Form
{

    private const int HOTKEY_ID_STOP = 1; // Esc��~�p

    // File�^�u�iBackstage�j�p
    private string? _currentMacroPath;

    // Core
    private readonly MacroAppService _app;
    private readonly BindingList<ActionRow> _rows = new();
    private readonly RecentFilesStore _recentFiles = new(appName: "MacroTool", maxItems: 10);

    // Recent Files �̎��ʗp�^�O�i���j���[�ɍ������ލ��ڂ���������悤�Ɂj

    // Status
    private ToolStripStatusLabel _lblState = null!;
    private ToolStripStatusLabel _lblElapsed = null!;
    private readonly System.Windows.Forms.Timer _statusTimer = new();

    // Dialog
    private readonly OpenFileDialog _openMacroDialog = new()
    {
        Filter = "Macro file (*.mcr)|*.mcr|JSON file (*.json)|*.json|All files (*.*)|*.*",
        Title = "�}�N�����J��"
    };

    private readonly SaveFileDialog _saveMacroDialog = new()
    {
        Filter = "Macro file (*.mcr)|*.mcr|JSON file (*.json)|*.json|All files (*.*)|*.*",
        Title = "�}�N����ۑ�",
        DefaultExt = "mcr",
        AddExtension = true,
        FileName = "macro.mcr"
    };
    private bool _isDirty = false;
    private bool _suppressDirty = false;


    public Form1(MacroAppService app)
    {
        //�R���X�g���N�^
        InitializeComponent();
        ApplyToolStripIcons();
        recentFilesToolStripMenuItem.DropDownOpening += (_, __) => RebuildRecentFilesMenu();

        settingsToolStripMenuItem.Click += (_, __) =>
            MessageBox.Show(this, "Settings �͖������ł��B", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        _app = app;

        _app.UserNotification += OnUserNotification;
        // --- StatusStrip�Ɂu��ԁv�u�o�߁v��ǉ��iDesigner�������Ȃ��j ---
        _lblState = new ToolStripStatusLabel
        {
            Name = "lblState",
            Text = "���: ��~",
            AutoSize = true
        };
        statusStrip1.Items.Insert(0, _lblState);

        _lblElapsed = new ToolStripStatusLabel
        {
            Name = "lblElapsed",
            Text = "�o�� 00:00:00",
            AutoSize = true
        };
        statusStrip1.Items.Add(_lblElapsed);

        // --- Core�G���W�� ---
        _app.StateChanged += (_, __) => BeginInvoke(new Action(UpdateUi));
        _app.MacroChanged += (_, __) => BeginInvoke(new Action(() =>
        {
            if (!_suppressDirty) _isDirty = true;
            RefreshGridFromDomain();
            UpdateUi();
        }));



        // --- �ꗗ�iDesigner�ō쐬����gridActions���g���j ---
        gridActions.AutoGenerateColumns = false;
        gridActions.DataSource = _rows;
        ConfigureGridColumns();
        gridActions.CellFormatting += GridActions_CellFormatting;
        gridActions.RowTemplate.Height = 22; // �A�C�R�����₷���i�C�Ӂj


        // --- ToolStrip�iRecord/Stop/Play�j ---
        HookToolStripButtons();

        // --- �X�e�[�^�X�X�V�^�C�}�[ ---
        _statusTimer.Interval = 250;
        _statusTimer.Tick += (_, __) => UpdateStatusBar();
        _statusTimer.Start();

        UpdateUi();
    }

    private void LoadMacroFromFile()
    {
        if (!ConfirmSaveIfDirty("�ǂݍ���"))
            return;

        if (_openMacroDialog.ShowDialog(this) != DialogResult.OK)
            return;

    }



    private void UpdateCurrentFileTitle()
    {
        // ��: MacroTool - 4.mcr
        Text = string.IsNullOrWhiteSpace(_currentMacroPath)
            ? "MacroTool"
            : $"MacroTool - {System.IO.Path.GetFileName(_currentMacroPath)}";
    }

    private void SaveMacro() => TrySaveWithPrompt(false);
    private void SaveMacroAs() => TrySaveWithPrompt(true);


    private bool TrySaveWithPrompt(bool forceSaveAs)
    {
        try
        {
            if (forceSaveAs || string.IsNullOrWhiteSpace(_currentMacroPath))
            {
                if (_saveMacroDialog.ShowDialog(this) != DialogResult.OK)
                    return false;

                _currentMacroPath = _saveMacroDialog.FileName;
            }

            _app.Save(_currentMacroPath!);
            _isDirty = false;
            _recentFiles.Add(_currentMacroPath!);

            UpdateUi();
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"�ۑ��Ɏ��s���܂����B\n{ex.Message}", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    private bool ConfirmSaveIfDirty(string actionName)
    {
        if (!_isDirty) return true;

        var result = MessageBox.Show(
            this,
            $"���ۑ��̕ύX������܂��B\n�ۑ����� {actionName} ���܂����H",
            "�m�F",
            MessageBoxButtons.YesNoCancel,
            MessageBoxIcon.Warning);

        switch (result)
        {
            case DialogResult.Yes:
                // �ۑ��ɐ��������瑱�s�A���s/�L�����Z���Ȃ璆�~
                return TrySaveWithPrompt(false);

            case DialogResult.No:
                // �ۑ��������s
                return true;

            default:
                // Cancel�i�ۑ������A���s�����Ȃ��j
                return false;
        }
    }

    // ===== ToolStrip (Record/Stop/Play) =====
    private void HookToolStripButtons()
    {
        static void Bind(ToolStripItem item, Action handler)
        {
            if (item is ToolStripSplitButton sb)
                sb.ButtonClick += (_, __) => handler();
            else
                item.Click += (_, __) => handler();
        }

        Bind(tsbRecord, StartRecording);
        Bind(tsbStop, () => _app.StopAll());
        Bind(tsbPlay, () =>
        {
            if (_app.State != MacroTool.Application.AppState.Stopped) return;
            if (_app.ActionCount == 0) return;
            _app.Play();
        });
    }

    private void StartRecording()
    {
        if (_app.State != MacroTool.Application.AppState.Stopped) return;

        bool ok = _app.StartRecording(clearExisting: true);
        if (!ok)
        {
            MessageBox.Show(
                "�^��J�n�Ɏ��s���܂����B\n�Ǘ��Ҍ������K�v�ȏꍇ������܂��B",
                "Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    // ===== Status =====
    private void UpdateStatusBar()
    {
        var state = _app.State;

        _lblState.Text = state switch
        {
            MacroTool.Application.AppState.Recording => "���: �^�撆�iEsc�Œ�~�j",
            MacroTool.Application.AppState.Playing => "���: �Đ����iEsc�Œ�~�j",
            _ => "���: ��~"
        };

        lblCount.Text = $"{_app.ActionCount} actions";

        lblTime.Text = $"�����܂� {FormatHms(_app.UntilDone())}";
        _lblElapsed.Text = $"�o�� {FormatHms(_app.Elapsed())}";
    }

    private void UpdateButtons()
    {
        var state = _app.State;

        // ��~�F�^��/�Đ��ł���A��~�͕s�v
        // �^�撆�F��~�ł���A�Đ��͕s�A�^��͕s��
        // �Đ����F��~�ł���A�^��͕s�A�Đ��͕s�i���d�Đ��h�~�j
        bool hasMacro = _app.ActionCount > 0;

        bool recordEnabled = state == MacroTool.Application.AppState.Stopped;
        bool playEnabled = state == MacroTool.Application.AppState.Stopped && hasMacro;
        bool stopEnabled = state != MacroTool.Application.AppState.Stopped;

        SetToolStripEnabled(tsbRecord, recordEnabled);
        SetToolStripEnabled(tsbPlay, playEnabled);
        SetToolStripEnabled(tsbStop, stopEnabled);
    }

    private static void SetToolStripEnabled(ToolStripItem item, bool enabled)
    {
        item.Enabled = enabled;

        if (item is ToolStripSplitButton sb)
        {
            foreach (ToolStripItem mi in sb.DropDownItems)
                mi.Enabled = enabled;
        }
    }

    private static string FormatHms(TimeSpan ts)
    {
        if (ts < TimeSpan.Zero) ts = TimeSpan.Zero;
        int hours = (int)ts.TotalHours;
        return $"{hours:00}:{ts.Minutes:00}:{ts.Seconds:00}";
    }

    // ===== HotKey (Esc) =====
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);

        if (!NativeMethods.RegisterHotKey(Handle, HOTKEY_ID_STOP, NativeMethods.MOD_NOREPEAT, (uint)Keys.Escape))
        {
            _lblState.Text = "���: ��~�iEsc��~�̓o�^�Ɏ��s�j";
        }
    }

    protected override void OnHandleDestroyed(EventArgs e)
    {
        NativeMethods.UnregisterHotKey(Handle, HOTKEY_ID_STOP);
        base.OnHandleDestroyed(e);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == NativeMethods.WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID_STOP)
        {
            _app.StopAll();
        }
        base.WndProc(ref m);
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (e.CloseReason == CloseReason.UserClosing)
        {
            if (!ConfirmSaveIfDirty("�I��"))
            {
                e.Cancel = true;
                return;
            }
        }
        _app.UserNotification -= OnUserNotification;
        _app.StopAll();          // �Đ�/�^���~�����͖���
        _app.Dispose();
        _statusTimer.Stop();
        base.OnFormClosing(e);
    }
    // ===== MenuStrip(File) =====
    private void openToolStripMenuItem_Click(object sender, EventArgs e) => LoadMacroFromFile();
    private void saveToolStripMenuItem_Click(object sender, EventArgs e) => SaveMacro();
    private void saveAsToolStripMenuItem_Click(object sender, EventArgs e) => SaveMacroAs();
    private void exitToolStripMenuItem_Click(object sender, EventArgs e) => Close();

    private sealed class ActionRow
    {
        public int No { get; set; }
        public string IconKey { get; set; } = "";
        public string Action { get; set; } = "";
        public string Value { get; set; } = "";
        public string Label { get; set; } = "";
        public string Comment { get; set; } = "";
    }

    private void RefreshGridFromDomain()
    {
        _rows.RaiseListChangedEvents = false;
        _rows.Clear();

        int i = 1;
        foreach (var step in _app.CurrentMacro.Steps)
        {
            _rows.Add(new ActionRow
            {
                No = i++,
                IconKey = ToIconKey(step.Action),
                Action = step.Action.Kind,
                Value = step.Action.DisplayValue,
                Label = "",    // �܂��h���C���ɖ�����΋��OK
                Comment = ""   // �܂��h���C���ɖ�����΋��OK
            });
        }

        _rows.RaiseListChangedEvents = true;
        _rows.ResetBindings();
    }

    private void OnUserNotification(object? sender, string msg)
    {
        if (IsDisposed) return;

        BeginInvoke(new Action(() =>
            MessageBox.Show(this, msg, "Info",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information)));
    }

    private void GridActions_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
    {
        // �w�b�_�s�Ȃǂ͖���
        if (e.RowIndex < 0) return;

        // 2��ڂ̃A�C�R���񂾂������i�񖼂��Ⴄ�ꍇ�͂�����ύX�j
        if (gridActions.Columns[e.ColumnIndex].Name != "colIcon") return;

        // �o�C���h����Ă���s�f�[�^���擾
        if (gridActions.Rows[e.RowIndex].DataBoundItem is not ActionRow row) return;

        // row.Action �� "MouseClick" / "KeyDown" / "KeyUp" ���������Ă���O��
        // ImageList��Name(Key)�� "mouse" "keyboard" �ɂ��Ă���ꍇ
        if (!string.IsNullOrWhiteSpace(row.IconKey) && imageList1.Images.ContainsKey(row.IconKey))
            e.Value = imageList1.Images[row.IconKey];
        else
            e.Value = null;

        e.FormattingApplied = true;
    }
    private void ConfigureGridColumns()
    {
        gridActions.AutoGenerateColumns = false;
        gridActions.AllowUserToAddRows = false;
        gridActions.AllowUserToDeleteRows = false;
        gridActions.ReadOnly = true;
        gridActions.MultiSelect = false;
        gridActions.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        // �s�w�b�_�̗]��������Ȃ����
        gridActions.RowHeadersVisible = false;

        // #��
        if (gridActions.Columns["colNo"] is DataGridViewColumn colNo)
        {
            colNo.DataPropertyName = nameof(ActionRow.No);
            colNo.Width = 40;
            colNo.Resizable = DataGridViewTriState.False;
        }

        // �A�C�R����iImageColumn�j
        if (gridActions.Columns["colIcon"] is DataGridViewImageColumn colIcon)
        {
            colIcon.Width = 26;
            colIcon.ImageLayout = DataGridViewImageCellLayout.Zoom;
            colIcon.Resizable = DataGridViewTriState.False;
            colIcon.DataPropertyName = ""; // �o�C���h���Ȃ��iCellFormatting�Ŗ��߂�j
        }

        // Action
        if (gridActions.Columns["colAction"] is DataGridViewColumn colAction)
        {
            colAction.DataPropertyName = nameof(ActionRow.Action);
            colAction.Width = 160;
        }

        // Value�i�L�т�j
        if (gridActions.Columns["colValue"] is DataGridViewColumn colValue)
        {
            colValue.DataPropertyName = nameof(ActionRow.Value);
            colValue.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colValue.FillWeight = 35;
        }

        // Label
        if (gridActions.Columns["colLabel"] is DataGridViewColumn colLabel)
        {
            colLabel.DataPropertyName = nameof(ActionRow.Label);
            colLabel.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colLabel.FillWeight = 20;
        }

        // Comment
        if (gridActions.Columns["colComment"] is DataGridViewColumn colComment)
        {
            colComment.DataPropertyName = nameof(ActionRow.Comment);
            colComment.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colComment.FillWeight = 45;
        }

        // ����G���[�_�C�A���O�}���i�ی��j
        gridActions.DataError += (_, e) => e.ThrowException = false;
    }
    private static class IconKeys
    {
        public const string Mouse = "Mouse";
        public const string Keyboard = "Keyboard";
        public const string Misc = "Misc";
    }

    private static string ToIconKey(DomainMacroAction action)
    {
        return action switch
        {
            DomainMouseClick => IconKeys.Mouse,
            DomainKeyDown or DomainKeyUp => IconKeys.Keyboard,
            _ => IconKeys.Misc
        };
    }
    private void UpdateUi()
    {
        UpdateCurrentFileTitle();
        UpdateStatusBar();
        UpdateButtons();
    }
    private void ApplyToolStripIcons()
    {
        // ToolStrip���̕\���T�C�Y�i�C�ӁF�����ڒ����j
        tsRecordEdit.ImageScalingSize = new System.Drawing.Size(32, 32);

        SetIcon(tsbPlay, "Play");
        SetIcon(tsbRecord, "Record");
        SetIcon(tsbStop, "Stop");

        // �K�v�Ȃ�ǉ�
        // SetIcon(tsbMouse, "Mouse");
        // SetIcon(tsbTextKey, "Keyboard");
        // SetIcon(tsbWait, "Wait");
        // SetIcon(tsbImageOcr, "Image");
        // SetIcon(tsbMisc, "Misc");
        // SetIcon(tsbEdit, "Edit");
        // SetIcon(tsbDelete, "Delete");
        // SetIcon(tsbSearchReplace, "Search");
    }

    private void SetIcon(ToolStripItem item, string key)
    {
        if (!imageListToolStrip.Images.ContainsKey(key))
            return;

        item.Image = imageListToolStrip.Images[key];
        item.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
        item.TextImageRelation = TextImageRelation.ImageAboveText;
    }
    private void RunWithoutDirty(Action action)
    {
        _suppressDirty = true;
        try { action(); }
        finally { _suppressDirty = false; }
    }

    private void newToolStripMenuItem_Click(object sender, EventArgs e)
    {
        if (!ConfirmSaveIfDirty("�V�K�쐬"))
            return;

        RunWithoutDirty(() => _app.New());

        _currentMacroPath = null;
        _isDirty = false;

        RefreshGridFromDomain();
        UpdateUi();


    }
    private void RebuildRecentFilesMenu()
    {
        // �����������Ȃ��́uFile�^�u(�h���b�v�_�E���̐e)�v�ɍ��킹�Ă�������
        ToolStripDropDownItem root = fileToolStripMenuItem;

        // ������ Recent �������ݕ���|��
        for (int i = root.DropDownItems.Count - 1; i >= 0; i--)
        {
            var it = root.DropDownItems[i];
            if (Equals(it.Tag, TAG_RECENT))
                root.DropDownItems.RemoveAt(i);
        }

        if (_recentFiles.Items.Count == 0)
            return;

        // �ǂ��ɍ������ނ��iExit �̒��O�ɓ����̂�������₷���j
        if (insertIndex < 0) insertIndex = root.DropDownItems.Count;

        // ��؂��
        root.DropDownItems.Insert(insertIndex++, new ToolStripSeparator { Tag = TAG_RECENT });

        // �ŋߎg�����t�@�C��
        int n = 1;
        foreach (var path in _recentFiles.Items)
        {
            var display = $"{n}. {Path.GetFileName(path)}";
            var item = new ToolStripMenuItem(display)
            {
                Tag = TAG_RECENT,
                ToolTipText = path
            };

            item.Click += (_, __) => LoadMacroFromPath(path);
            root.DropDownItems.Insert(insertIndex++, item);
            n++;
        }

        // �N���A
        root.DropDownItems.Insert(insertIndex++, new ToolStripSeparator { Tag = TAG_RECENT });

        var clear = new ToolStripMenuItem("Clear Recent Files")
        {
            Tag = TAG_RECENT
        };
        clear.Click += (_, __) =>
        {
            _recentFiles.Clear();
            // ����J�����Ƃ��ɏ����Ă���i�������f�������Ȃ������x Rebuild �Ă�ł�OK�j
        };

        root.DropDownItems.Insert(insertIndex++, clear);
    }

    private void LoadMacroFromPath(string path)
    {
        // ���ۑ��m�F�i�d�l�FYes/No/Cancel�j
        if (!ConfirmSaveIfDirty("�ǂݍ���"))
            return;

        if (!File.Exists(path))
        {
            MessageBox.Show(this, $"�t�@�C����������܂���B\n{path}", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            _recentFiles.Remove(path);
            return;
        }

        try
        {
            _suppressDirty = true;
            _app.Load(path);
            _suppressDirty = false;

            _currentMacroPath = path;
            _isDirty = false;

            _recentFiles.Add(path); // �擪�ֈړ�
            UpdateUi();
        }
        catch (Exception ex)
        {
            _suppressDirty = false;

            MessageBox.Show(this, $"�ǂݍ��݂Ɏ��s���܂����B\n{ex.Message}", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void RebuildRecentFilesMenu()
    {
        recentFilesToolStripMenuItem.DropDownItems.Clear();

        var recents = _recentFiles.Items;

        if (recents.Count == 0)
        {
            recentFilesToolStripMenuItem.DropDownItems.Add(
                new ToolStripMenuItem("(none)") { Enabled = false }
            );
            return;
        }

        int n = 1;
        foreach (var path in recents)
        {
            var text = $"{n}. {Path.GetFileName(path)}";

            var item = new ToolStripMenuItem(text)
            {
                ToolTipText = path,
                Tag = path
            };

            item.Click += (_, __) => LoadMacroFromPath(path);

            recentFilesToolStripMenuItem.DropDownItems.Add(item);
            n++;
        }

        recentFilesToolStripMenuItem.DropDownItems.Add(new ToolStripSeparator());

        var clear = new ToolStripMenuItem("Clear Recent Files");
        clear.Click += (_, __) =>
        {
            _recentFiles.Clear();
            RebuildRecentFilesMenu(); // �������f
        };

        recentFilesToolStripMenuItem.DropDownItems.Add(clear);
    }


}
